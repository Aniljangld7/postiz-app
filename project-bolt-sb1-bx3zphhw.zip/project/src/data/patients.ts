import type { Patient } from '../types';

export const patients: Patient[] = [
  {
    id: 'P001',
    name: 'Emma Thompson',
    age: 45,
    gender: 'Female',
    bloodType: 'A+',
    contact: {
      email: 'emma.t@email.com',
      phone: '(555) 123-4567',
      address: '123 Health St, Medical City, MC 12345'
    },
    insurance: {
      provider: 'HealthGuard Insurance',
      policyNumber: 'HG-123456789'
    },
    riskScores: {
      diabetes: 35,
      hypertension: 45,
      heartDisease: 20,
      obesity: 15
    },
    medicalHistory: [
      {
        id: 'MR001',
        date: '2024-02-15',
        type: 'diagnosis',
        title: 'Annual Physical Examination',
        description: 'Regular checkup shows normal vital signs. Blood pressure slightly elevated at 130/85. Recommended lifestyle modifications.',
        doctor: 'Dr. Sarah Chen',
        status: 'completed',
        priority: 'medium'
      },
      {
        id: 'MR002',
        date: '2024-02-01',
        type: 'lab_result',
        title: 'Comprehensive Blood Panel',
        description: 'Cholesterol: 210 mg/dL (borderline high)\nBlood Sugar (Fasting): 95 mg/dL (normal)\nHemoglobin: 13.5 g/dL (normal)',
        doctor: 'Dr. Michael Rodriguez',
        status: 'completed',
        priority: 'medium'
      },
      {
        id: 'MR003',
        date: '2024-03-15',
        type: 'procedure',
        title: 'Cardiac Stress Test',
        description: 'Scheduled for routine cardiac evaluation',
        doctor: 'Dr. James Wilson',
        status: 'scheduled',
        priority: 'medium'
      }
    ]
  },
  {
    id: 'P002',
    name: 'Robert Chen',
    age: 52,
    gender: 'Male',
    bloodType: 'O+',
    contact: {
      email: 'robert.c@email.com',
      phone: '(555) 987-6543',
      address: '456 Wellness Ave, Medical City, MC 12345'
    },
    insurance: {
      provider: 'MediCare Plus',
      policyNumber: 'MP-987654321'
    },
    riskScores: {
      diabetes: 55,
      hypertension: 60,
      heartDisease: 45,
      obesity: 30
    },
    medicalHistory: [
      {
        id: 'MR004',
        date: '2024-02-10',
        type: 'prescription',
        title: 'Medication Review',
        description: 'Prescribed Metformin 500mg for diabetes management. Take twice daily with meals.',
        doctor: 'Dr. Emily Parker',
        status: 'completed',
        priority: 'high'
      },
      {
        id: 'MR005',
        date: '2024-01-25',
        type: 'lab_result',
        title: 'HbA1c Test',
        description: 'HbA1c: 7.2% (elevated)\nRecommended lifestyle changes and medication adjustment.',
        doctor: 'Dr. Emily Parker',
        status: 'completed',
        priority: 'high'
      }
    ]
  }
];