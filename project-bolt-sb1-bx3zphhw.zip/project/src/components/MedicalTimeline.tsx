import React from 'react';
import { Calendar, Stethoscope, FlaskRound as Flask, FileText, Syringe, AlertCircle } from 'lucide-react';
import type { MedicalRecord } from '../types';

const icons = {
  diagnosis: Stethoscope,
  prescription: FileText,
  lab_result: Flask,
  note: Calendar,
  procedure: Syringe
};

const priorityColors = {
  low: 'bg-green-50 text-green-700',
  medium: 'bg-yellow-50 text-yellow-700',
  high: 'bg-red-50 text-red-700'
};

const statusColors = {
  completed: 'bg-green-50 text-green-700',
  scheduled: 'bg-blue-50 text-blue-700',
  cancelled: 'bg-gray-50 text-gray-700'
};

interface MedicalTimelineProps {
  records: MedicalRecord[];
}

export function MedicalTimeline({ records }: MedicalTimelineProps) {
  return (
    <div className="flow-root">
      <ul role="list" className="-mb-8">
        {records.map((record, recordIdx) => {
          const Icon = icons[record.type];
          return (
            <li key={record.id}>
              <div className="relative pb-8">
                {recordIdx !== records.length - 1 ? (
                  <span
                    className="absolute left-4 top-4 -ml-px h-full w-0.5 bg-gray-200"
                    aria-hidden="true"
                  />
                ) : null}
                <div className="relative flex gap-6">
                  <div>
                    <span className="h-8 w-8 rounded-full bg-blue-50 flex items-center justify-center ring-8 ring-white">
                      <Icon className="h-5 w-5 text-blue-600" aria-hidden="true" />
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-3">
                        <h3 className="text-base font-semibold text-gray-900">
                          {record.title}
                        </h3>
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[record.status]}`}>
                          {record.status}
                        </span>
                        {record.priority === 'high' && (
                          <span className="flex items-center gap-1 text-red-600 text-sm">
                            <AlertCircle className="w-4 h-4" />
                            High Priority
                          </span>
                        )}
                      </div>
                      <time className="text-sm text-gray-500" dateTime={record.date}>
                        {new Date(record.date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })}
                      </time>
                    </div>
                    <p className="text-sm text-gray-700 whitespace-pre-line">
                      {record.description}
                    </p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-sm text-gray-500">
                        By: {record.doctor}
                      </span>
                      {record.attachments && record.attachments.length > 0 && (
                        <button className="text-sm text-blue-600 hover:text-blue-700">
                          View Attachments ({record.attachments.length})
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}