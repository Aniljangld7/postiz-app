import React from 'react';
import { User, Activity, Phone, Mail, Calendar, Droplet } from 'lucide-react';
import type { Database } from '../types/supabase';

type Patient = Database['public']['Tables']['patients']['Row'];

interface PatientCardProps {
  patient: Patient;
  onClick: (patient: Patient) => void;
}

export function PatientCard({ patient, onClick }: PatientCardProps) {
  const riskScores = patient.risk_scores as {
    diabetes: number;
    hypertension: number;
    heartDisease: number;
    obesity: number;
  };

  const getHighestRisk = () => {
    const risks = Object.entries(riskScores);
    return risks.reduce((max, current) => 
      current[1] > max[1] ? current : max
    );
  };

  const [highestRiskFactor, highestRiskValue] = getHighestRisk();
  const contact = patient.contact as { email: string; phone: string; address: string };
  const insurance = patient.insurance as { provider: string; policyNumber: string };

  return (
    <div 
      onClick={() => onClick(patient)}
      className="p-6 bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-blue-100 rounded-full">
            <User className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{patient.name}</h3>
            <div className="flex items-center gap-4 mt-1">
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Calendar className="w-4 h-4" />
                <span>Age: {patient.age}</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Droplet className="w-4 h-4" />
                <span>{patient.blood_type}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-500">{contact.phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-500">{contact.email}</span>
          </div>
        </div>
      </div>

      <div className="mt-6 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-gray-500">Highest Risk Factor</span>
          <span className="text-sm font-medium text-gray-900">
            {highestRiskFactor.replace(/([A-Z])/g, ' $1').trim()}: {highestRiskValue}%
          </span>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {Object.entries(riskScores).map(([key, value]) => (
            <div key={key} className="p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500 capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <div 
                  className="w-full bg-gray-200 rounded-full h-2.5"
                  title={`${value}% risk`}
                >
                  <div 
                    className={`h-2.5 rounded-full ${
                      value > 50 ? 'bg-red-500' : value > 30 ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${value}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {value}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 pt-4 border-t border-gray-100">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">Insurance Provider:</span>
          <span className="font-medium text-gray-900">{insurance.provider}</span>
        </div>
      </div>
    </div>
  );
}