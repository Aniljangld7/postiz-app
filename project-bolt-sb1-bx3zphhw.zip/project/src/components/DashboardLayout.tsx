import React from 'react';
import { Layout, Sidebar, Users, FileText, Activity, LogOut } from 'lucide-react';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200">
        <div className="flex items-center gap-2 px-6 py-4 border-b border-gray-200">
          <Layout className="w-6 h-6 text-blue-600" />
          <span className="text-xl font-semibold">MedHistory</span>
        </div>
        
        <nav className="p-4 space-y-2">
          <a href="#" className="flex items-center gap-2 px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <Users className="w-5 h-5" />
            <span>Patients</span>
          </a>
          <a href="#" className="flex items-center gap-2 px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <FileText className="w-5 h-5" />
            <span>Records</span>
          </a>
          <a href="#" className="flex items-center gap-2 px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <Activity className="w-5 h-5" />
            <span>Analytics</span>
          </a>
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-gray-200">
          <button className="flex items-center gap-2 px-4 py-2 w-full text-gray-700 rounded-lg hover:bg-gray-100">
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64 p-8">
        {children}
      </div>
    </div>
  );
}