import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Patient } from '../types';
import toast from 'react-hot-toast';

interface PatientState {
  patients: Patient[];
  loading: boolean;
  selectedPatient: Patient | null;
  fetchPatients: () => Promise<void>;
  addPatient: (patient: Omit<Patient, 'id'>) => Promise<void>;
  updatePatient: (id: string, patient: Partial<Patient>) => Promise<void>;
  setSelectedPatient: (patient: Patient | null) => void;
}

export const usePatientStore = create<PatientState>((set, get) => ({
  patients: [],
  loading: false,
  selectedPatient: null,
  fetchPatients: async () => {
    set({ loading: true });
    try {
      const { data, error } = await supabase
        .from('patients')
        .select('*');
      
      if (error) throw error;
      set({ patients: data as Patient[] });
    } catch (error) {
      toast.error('Failed to fetch patients');
      console.error('Error:', error);
    } finally {
      set({ loading: false });
    }
  },
  addPatient: async (patient) => {
    try {
      const { data, error } = await supabase
        .from('patients')
        .insert([patient])
        .select()
        .single();
      
      if (error) throw error;
      
      set((state) => ({
        patients: [...state.patients, data as Patient]
      }));
      
      toast.success('Patient added successfully');
    } catch (error) {
      toast.error('Failed to add patient');
      console.error('Error:', error);
    }
  },
  updatePatient: async (id, patient) => {
    try {
      const { data, error } = await supabase
        .from('patients')
        .update(patient)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      
      set((state) => ({
        patients: state.patients.map((p) => 
          p.id === id ? { ...p, ...data } as Patient : p
        )
      }));
      
      toast.success('Patient updated successfully');
    } catch (error) {
      toast.error('Failed to update patient');
      console.error('Error:', error);
    }
  },
  setSelectedPatient: (patient) => set({ selectedPatient: patient }),
}));