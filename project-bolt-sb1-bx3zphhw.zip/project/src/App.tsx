import React, { useEffect, useState } from 'react';
import { DashboardLayout } from './components/DashboardLayout';
import { PatientCard } from './components/PatientCard';
import { MedicalTimeline } from './components/MedicalTimeline';
import { AuthForm } from './components/AuthForm';
import { AddPatientForm } from './components/AddPatientForm';
import { Plus, Search } from 'lucide-react';
import { useAuthStore } from './store/authStore';
import { usePatientStore } from './store/patientStore';
import { Toaster } from 'react-hot-toast';
import { supabase } from './lib/supabase';

function App() {
  const { user, setUser, setSession } = useAuthStore();
  const { 
    patients, 
    selectedPatient, 
    setSelectedPatient, 
    fetchPatients,
    loading 
  } = usePatientStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddPatient, setShowAddPatient] = useState(false);

  useEffect(() => {
    // Check active sessions and set up auth listener
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      fetchPatients();
    }
  }, [user]);

  if (!user) {
    return <AuthForm />;
  }

  const filteredPatients = patients.filter(patient => 
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Toaster position="top-right" />
      <DashboardLayout>
        <div className="max-w-7xl mx-auto">
          {selectedPatient ? (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setSelectedPatient(null)}
                  className="text-blue-600 hover:text-blue-700 flex items-center gap-2"
                >
                  ← Back to all patients
                </button>
                <div className="flex items-center gap-4">
                  <button className="px-4 py-2 text-blue-600 hover:text-blue-700 border border-blue-600 rounded-lg">
                    Edit Patient
                  </button>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    Schedule Appointment
                  </button>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900">
                        {selectedPatient.name}
                      </h2>
                      <p className="mt-1 text-sm text-gray-500">
                        Patient ID: {selectedPatient.id} • Blood Type: {selectedPatient.blood_type}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">{selectedPatient.contact.phone}</p>
                      <p className="text-sm text-gray-500">{selectedPatient.contact.email}</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Medical History
                  </h3>
                  <MedicalTimeline records={selectedPatient.medical_records || []} />
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold text-gray-900">Patient Dashboard</h1>
                <button 
                  onClick={() => setShowAddPatient(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
                >
                  <Plus className="w-5 h-5" />
                  Add New Patient
                </button>
              </div>

              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search patients by name or ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              {loading ? (
                <div className="text-center py-12">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-blue-500 border-t-transparent"></div>
                  <p className="mt-2 text-gray-600">Loading patients...</p>
                </div>
              ) : filteredPatients.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-600">No patients found</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredPatients.map((patient) => (
                    <PatientCard
                      key={patient.id}
                      patient={patient}
                      onClick={setSelectedPatient}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </DashboardLayout>

      {showAddPatient && (
        <AddPatientForm onClose={() => setShowAddPatient(false)} />
      )}
    </>
  );
}

export default App;