export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      patients: {
        Row: {
          id: string
          name: string
          age: number
          gender: string
          blood_type: string
          contact: Json
          insurance: Json
          risk_scores: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          age: number
          gender: string
          blood_type: string
          contact: Json
          insurance: Json
          risk_scores: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          age?: number
          gender?: string
          blood_type?: string
          contact?: Json
          insurance?: Json
          risk_scores?: Json
          created_at?: string
          updated_at?: string
        }
      }
      medical_records: {
        Row: {
          id: string
          patient_id: string
          type: string
          title: string
          description: string
          doctor: string
          status: string
          priority: string
          date: string
          attachments: string[] | null
          created_at: string
        }
        Insert: {
          id?: string
          patient_id: string
          type: string
          title: string
          description: string
          doctor: string
          status: string
          priority: string
          date: string
          attachments?: string[] | null
          created_at?: string
        }
        Update: {
          id?: string
          patient_id?: string
          type?: string
          title?: string
          description?: string
          doctor?: string
          status?: string
          priority?: string
          date?: string
          attachments?: string[] | null
          created_at?: string
        }
      }
      appointments: {
        Row: {
          id: string
          patient_id: string
          doctor: string
          date: string
          reason: string
          status: string
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          patient_id: string
          doctor: string
          date: string
          reason: string
          status?: string
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          patient_id?: string
          doctor?: string
          date?: string
          reason?: string
          status?: string
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}