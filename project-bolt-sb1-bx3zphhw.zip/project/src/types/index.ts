export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  bloodType: string;
  medicalHistory: MedicalRecord[];
  riskScores: RiskScores;
  contact: {
    email: string;
    phone: string;
    address: string;
  };
  insurance: {
    provider: string;
    policyNumber: string;
  };
}

export interface MedicalRecord {
  id: string;
  date: string;
  type: 'diagnosis' | 'prescription' | 'lab_result' | 'note' | 'procedure';
  title: string;
  description: string;
  doctor: string;
  status: 'completed' | 'scheduled' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  attachments?: string[];
}

export interface RiskScores {
  diabetes: number;
  hypertension: number;
  heartDisease: number;
  obesity: number;
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  email: string;
  phone: string;
  department: string;
}